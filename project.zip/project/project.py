print("Hello, Synergy!")
print("Hello, Ubuntu!")
print("Hello, Docker!")